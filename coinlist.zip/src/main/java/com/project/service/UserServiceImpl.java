package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.mapper.UserMapper;
import com.project.model.UserVO;

@Service
public class UserServiceImpl implements UserService
{

	@Autowired
	UserMapper usermapper;

	// �α���
	@Override
	public UserVO userLogin(UserVO user) throws Exception
	{
		return usermapper.userLogin(user);
	}

	// ȸ�����
	@Override
	public void userRegister(UserVO user) throws Exception
	{
		usermapper.userRegister(user);
	}

	// ȸ������
	@Override
	public void userUpdate(UserVO user) throws Exception
	{
		usermapper.userUpdate(user);
	}

	// ȸ������
	@Override
	public void userDelete(UserVO user) throws Exception
	{
		usermapper.userDelete(user);
	}

	// ���̵� �ߺ� üũ
	@Override
	public int useridCheck(String u_id) throws Exception
	{
		return usermapper.useridCheck(u_id);
	}

}
